import { Kafka } from 'kafkajs'
import bcrypt from "bcryptjs"

const kafka = new Kafka({
    clientId: 'user-service',
    brokers: ['localhost:9092']
})
const producer = kafka.producer()

export async function connectProducer(){
    await producer.connect()
    console.log('Kafka producer connected')
}

export async function registerUser(req) {
   
    const userEvent = {
        eventType: 'UserRegistered',
        email: req.body.email,
        password: bcrypt.hashSync(req.body.password)
    }

    await producer.send({
        topic: 'user-events',
        messages: [
            { value: JSON.stringify(userEvent) }
        ]
    })
    console.log('User Service: Published event for Register User -> ', userEvent)
    await producer.disconnect()
}

export default registerUser 