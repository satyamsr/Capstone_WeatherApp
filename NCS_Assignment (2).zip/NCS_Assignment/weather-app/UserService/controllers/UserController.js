import UserModel from "../models/UserModel.js"
import bcrypt from "bcryptjs"
import dotenv from "dotenv"
import { v4 as uuidv4 } from 'uuid'
import registerUser from "../KafkaProducer.js"

dotenv.config()

async function GetUsers(req, res) {
    let users = await UserModel.find({})
    res.send(users)
}

async function GetUserById(req, res) {
    let user = await UserModel.findOne({ userId: req.params.id })
    res.send(user)  
}

async function register(req, res) {
    const user = await UserModel.findOne({ email: req.body.email })
    if (user) {
        res.status(409).send({ status: 409, message: 'User with specified email already exists' })
    } else if (!user) {
        const user = new UserModel({
            userId: uuidv4(),
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            password: bcrypt.hashSync(req.body.password)
        })
        await user.save()
        await registerUser(req)
        res.status(201).send({ message: 'User registered successfully' })
    } else {
        res.send(err)
    }
}

async function DeleteUser(req, res) {
    await UserModel.deleteOne({userId: req.params.id})
    res.send({ status : 200, message : "User Delete Successfully"})
}

async function UpdateUser(req, res) {
    await UserModel.updateOne({ userId: req.params.id},
    {
        userId: uuidv4(),
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        password: bcrypt.hashSync(req.body.password)
    }
)
res.send({status : 200, message : "User updated successfully"})    
}

export { GetUsers, GetUserById, register, DeleteUser, UpdateUser }