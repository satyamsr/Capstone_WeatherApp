import { Kafka } from 'kafkajs'

const kafka = new Kafka({
    clientId: 'test-client',
    brokers: ['localhost:9092']
})
const producer = kafka.producer()

async function run() {

    try{
    console.log('Connecting to Kafka...')

    await producer.connect()
    console.log('Connected successfully.')

    console.log('Sending test message...')

    const userEvent = {
            eventType: 'UserRegistered',
            email: "satyam@yahoo.co.in",
            password: "12345"
        }

    await producer.send({
        topic: 'user-events',
        messages: [
            { value: JSON.stringify(userEvent) }
        ]
    })  
    console.log('Message sent successfully') 
    //console.log('User Service: Published event for Register User -> ', userEvent)
    await producer.disconnect()
    console.log('Disconnected.')
} catch(err){
    console.error('KAFKA TEST FAILED', err)
}
}

run()