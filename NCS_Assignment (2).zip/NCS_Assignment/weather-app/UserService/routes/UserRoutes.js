import express from "express"
import { GetUsers, GetUserById, register, DeleteUser, UpdateUser } from "../controllers/UserController.js"

const router = express.Router()

router.get('/', GetUsers)
router.get('/:id', GetUserById)
router.post('/register', register)
router.put('/:id', UpdateUser)
router.delete('/:id', DeleteUser)

export default router