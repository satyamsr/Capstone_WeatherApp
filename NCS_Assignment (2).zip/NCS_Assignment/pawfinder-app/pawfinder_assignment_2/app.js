const API_URL = "http://localhost:3000/animals";

let animals = [];

const animalForm = document.getElementById("animalForm");
const animalsContainer = document.getElementById("animalsContainer");
const emptyState = document.getElementById("emptyState");
const apiMessage = document.getElementById("apiMessage");

const searchInput = document.getElementById("searchInput");
const speciesFilter = document.getElementById("speciesFilter");
const statusFilter = document.getElementById("statusFilter");
const sortFilter = document.getElementById("sortFilter");
const clearFiltersButton = document.getElementById("clearFiltersButton");

const totalCount = document.getElementById("totalCount");
const availableCount = document.getElementById("availableCount");
const adoptedCount = document.getElementById("adoptedCount");

const animalIdInput = document.getElementById("animalId");
const formHeading = document.getElementById("form-heading");
const formModeBadge = document.getElementById("formModeBadge");
const submitButton = document.getElementById("submitButton");
const cancelEditButton = document.getElementById("cancelEditButton");

const formFields = {
  name: document.getElementById("name"),
  species: document.getElementById("species"),
  breed: document.getElementById("breed"),
  age: document.getElementById("age"),
  gender: document.getElementById("gender"),
  vaccinated: document.getElementById("vaccinated"),
  arrivalDate: document.getElementById("arrivalDate"),
  status: document.getElementById("status"),
  notes: document.getElementById("notes"),
  photoUrl: document.getElementById("photoUrl")
};

const errorElements = {
  name: document.getElementById("nameError"),
  species: document.getElementById("speciesError"),
  breed: document.getElementById("breedError"),
  age: document.getElementById("ageError"),
  gender: document.getElementById("genderError"),
  arrivalDate: document.getElementById("arrivalDateError"),
  status: document.getElementById("statusError"),
  photoUrl: document.getElementById("photoUrlError")
};

const allowedSpecies = ["Dog", "Cat", "Rabbit", "Other"];
const allowedGenders = ["Male", "Female"];
const allowedStatuses = ["Available", "Adopted"];


/* =========================================================
   EVENT LISTENERS
   ========================================================= */

document.addEventListener("DOMContentLoaded", loadAnimals);

animalForm.addEventListener("submit", handleFormSubmit);

cancelEditButton.addEventListener("click", resetForm);

searchInput.addEventListener("input", renderAnimals);

speciesFilter.addEventListener("change", renderAnimals);

statusFilter.addEventListener("change", renderAnimals);

sortFilter.addEventListener("change", renderAnimals);

clearFiltersButton.addEventListener("click", () => {
  searchInput.value = "";
  speciesFilter.value = "All";
  statusFilter.value = "All";
  sortFilter.value = "name";

  renderAnimals();
});


/*
 * Event delegation:
 * Instead of adding a click listener to every Edit,
 * Adopt, and Delete button, we add ONE listener to
 * the parent container.
 */
animalsContainer.addEventListener("click", handleCardAction);


/* =========================================================
   GET /animals
   ========================================================= */

async function loadAnimals() {
  hideApiMessage();

  try {
    const response = await fetch(API_URL);

    if (!response.ok) {
      throw new Error(`Unable to load animals (${response.status}).`);
    }

    animals = await response.json();

    renderAnimals();

  } catch (error) {

    animals = [];

    renderAnimals();

    showApiMessage(
      "danger",
      `The animal list could not be loaded. Make sure json-server is running on port 3000. ${error.message}`
    );
  }
}


/* =========================================================
   FILTER + SEARCH + SORT
   ========================================================= */

function applyFilters() {

  const searchTerm = searchInput.value
    .trim()
    .toLowerCase();

  const selectedSpecies = speciesFilter.value;

  const selectedStatus = statusFilter.value;

  const selectedSort = sortFilter.value;


  const filteredAnimals = animals

    .filter((animal) => {

      const matchesSearch =
        !searchTerm ||
        animal.name.toLowerCase().includes(searchTerm) ||
        animal.breed.toLowerCase().includes(searchTerm);


      const matchesSpecies =
        selectedSpecies === "All" ||
        animal.species === selectedSpecies;


      const matchesStatus =
        selectedStatus === "All" ||
        animal.status === selectedStatus;


      return (
        matchesSearch &&
        matchesSpecies &&
        matchesStatus
      );
    })


    .sort((first, second) => {

      if (selectedSort === "age") {
        return Number(first.age) - Number(second.age);
      }

      return first.name.localeCompare(second.name);
    });


  return filteredAnimals;
}


/* =========================================================
   RENDER ANIMALS
   ========================================================= */

function renderAnimals() {

  const filteredAnimals = applyFilters();


  /*
   * Remove existing cards from the DOM.
   *
   * replaceChildren() is used instead of innerHTML.
   */
  animalsContainer.replaceChildren();


  filteredAnimals.forEach((animal) => {

    const animalCard = buildAnimalCard(animal);

    animalsContainer.appendChild(animalCard);
  });


  /*
   * Show empty state if there are no matching records.
   */
  emptyState.classList.toggle(
    "d-none",
    filteredAnimals.length !== 0
  );


  updateSummary();
}


/* =========================================================
   BUILD ANIMAL CARD
   ========================================================= */

function buildAnimalCard(animal) {

  const column = document.createElement("div");

  column.className = "col-md-6 col-xl-4";


  const card = document.createElement("article");

  card.className =
    "card animal-card shadow-sm border-0";


  /*
   * Adopted animals are visually muted.
   */
  if (animal.status === "Adopted") {

    card.classList.add("adopted");
  }


  /* ---------------------------------------------------------
     IMAGE SECTION
     --------------------------------------------------------- */

  const imageWrapper = document.createElement("div");

  imageWrapper.className =
    "position-relative";


  const image = document.createElement("img");

  image.className =
    "card-img-top animal-photo";

  image.src = animal.photoUrl;

  image.alt =
    `${animal.name}, ${animal.species}`;

  image.loading = "lazy";


  /* ---------------------------------------------------------
     STATUS BADGE
     --------------------------------------------------------- */

  const statusBadge = document.createElement("span");

  statusBadge.className =
    `badge status-badge ${
      animal.status === "Adopted"
        ? "text-bg-secondary"
        : "text-bg-success"
    }`;

  statusBadge.textContent =
    animal.status;


  imageWrapper.append(
    image,
    statusBadge
  );


  /* ---------------------------------------------------------
     CARD BODY
     --------------------------------------------------------- */

  const body = document.createElement("div");

  body.className =
    "card-body d-flex flex-column";


  /* ---------------------------------------------------------
     TITLE
     --------------------------------------------------------- */

  const titleRow = document.createElement("div");

  titleRow.className =
    "d-flex justify-content-between align-items-start gap-2";


  const title = document.createElement("h3");

  title.className =
    "h4 card-title mb-1";

  title.textContent =
    animal.name;


  const speciesBadge = document.createElement("span");

  speciesBadge.className =
    "badge text-bg-light border";

  speciesBadge.textContent =
    animal.species;


  titleRow.append(
    title,
    speciesBadge
  );


  /* ---------------------------------------------------------
     ANIMAL DETAILS
     --------------------------------------------------------- */

  const details = document.createElement("p");

  details.className =
    "card-text mb-2 text-muted";


  details.textContent =
    `${animal.breed} • ${animal.age} year${
      Number(animal.age) === 1 ? "" : "s"
    } • ${animal.gender}`;


  /* ---------------------------------------------------------
     VACCINATION
     --------------------------------------------------------- */

  const vaccination = document.createElement("p");

  vaccination.className =
    "small mb-2";


  vaccination.textContent =
    animal.vaccinated
      ? "✓ Vaccinations up to date"
      : "⚠ Vaccinations need attention";


  /* ---------------------------------------------------------
     ARRIVAL DATE
     --------------------------------------------------------- */

  const arrival = document.createElement("p");

  arrival.className =
    "small text-muted mb-2";

  arrival.textContent =
    `Arrived: ${animal.arrivalDate}`;


  /* ---------------------------------------------------------
     NOTES
     --------------------------------------------------------- */

  const notes = document.createElement("p");

  notes.className =
    "animal-notes small mb-3";

  notes.textContent =
    animal.notes || "No notes recorded.";


  /* ---------------------------------------------------------
     ACTION BUTTONS
     --------------------------------------------------------- */

  const actions = document.createElement("div");

  actions.className =
    "mt-auto d-flex gap-2";


  /* EDIT BUTTON */

  const editButton = document.createElement("button");

  editButton.type = "button";

  editButton.className =
    "btn btn-outline-primary btn-sm";

  editButton.dataset.action = "edit";

  editButton.dataset.id = animal.id;

  editButton.textContent =
    "Edit";


  /* ADOPT BUTTON */

  const adoptButton = document.createElement("button");

  adoptButton.type = "button";

  adoptButton.className =
    "btn btn-success btn-sm";

  adoptButton.dataset.action = "adopt";

  adoptButton.dataset.id = animal.id;

  adoptButton.textContent =
    "Adopt";


  /*
   * Adopt button becomes disabled once
   * the animal has already been adopted.
   */
  adoptButton.disabled =
    animal.status === "Adopted";


  /* DELETE BUTTON */

  const deleteButton = document.createElement("button");

  deleteButton.type = "button";

  deleteButton.className =
    "btn btn-outline-danger btn-sm ms-auto";

  deleteButton.dataset.action = "delete";

  deleteButton.dataset.id = animal.id;

  deleteButton.textContent =
    "Delete";


  actions.append(
    editButton,
    adoptButton,
    deleteButton
  );


  body.append(
    titleRow,
    details,
    vaccination,
    arrival,
    notes,
    actions
  );


  card.append(
    imageWrapper,
    body
  );


  column.appendChild(card);


  /*
   * IMPORTANT:
   *
   * We create DOM elements individually instead of using
   * one large innerHTML string.
   *
   * This matters because name, breed, notes, etc. can come
   * from users or external API data. Using textContent treats
   * the data as text instead of allowing it to become HTML.
   * This helps prevent accidental HTML/script injection.
   */

  return column;
}


/* =========================================================
   SUMMARY BAR
   ========================================================= */

function updateSummary() {

  const summary = animals.reduce(
    (counts, animal) => {

      counts.total += 1;


      if (animal.status === "Available") {

        counts.available += 1;

      } else if (animal.status === "Adopted") {

        counts.adopted += 1;
      }


      return counts;

    },
    {
      total: 0,
      available: 0,
      adopted: 0
    }
  );


  totalCount.textContent =
    summary.total;

  availableCount.textContent =
    summary.available;

  adoptedCount.textContent =
    summary.adopted;
}


/* =========================================================
   DELEGATED CARD ACTION
   ========================================================= */

async function handleCardAction(event) {

  const button =
    event.target.closest(
      "button[data-action]"
    );


  if (
    !button ||
    !animalsContainer.contains(button)
  ) {
    return;
  }


  const { action, id } =
    button.dataset;


  if (action === "edit") {

    await loadAnimalIntoForm(id);

  } else if (action === "adopt") {

    await markAsAdopted(id);

  } else if (action === "delete") {

    await deleteAnimal(id);
  }
}


/* =========================================================
   GET /animals/:id
   ========================================================= */

async function loadAnimalIntoForm(id) {

  hideApiMessage();


  try {

    const response =
      await fetch(
        `${API_URL}/${encodeURIComponent(id)}`
      );


    if (!response.ok) {

      throw new Error(
        `Unable to load animal (${response.status}).`
      );
    }


    const animal =
      await response.json();


    /*
     * Populate form fields.
     */

    animalIdInput.value =
      animal.id;

    formFields.name.value =
      animal.name;

    formFields.species.value =
      animal.species;

    formFields.breed.value =
      animal.breed;

    formFields.age.value =
      animal.age;

    formFields.gender.value =
      animal.gender;

    formFields.vaccinated.checked =
      Boolean(animal.vaccinated);

    formFields.arrivalDate.value =
      animal.arrivalDate;

    formFields.status.value =
      animal.status;

    formFields.notes.value =
      animal.notes || "";

    formFields.photoUrl.value =
      animal.photoUrl;


    clearValidation();

    setEditMode(true);


    /*
     * Scroll back to the form.
     */

    animalForm.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });


  } catch (error) {

    showApiMessage(
      "danger",
      `Could not load that animal for editing. ${error.message}`
    );
  }
}


/* =========================================================
   CREATE / UPDATE
   POST /animals
   PUT /animals/:id
   ========================================================= */

async function handleFormSubmit(event) {

  /*
   * Prevent normal form submission/page reload.
   */

  event.preventDefault();


  hideApiMessage();

  clearValidation();


  /*
   * Validate before making any API request.
   */

  const validationErrors =
    validateForm();


  if (
    Object.keys(validationErrors).length > 0
  ) {

    showValidationErrors(
      validationErrors
    );

    return;
  }


  const animalData =
    getFormData();


  const editingId =
    animalIdInput.value.trim();


  const isEditing =
    Boolean(editingId);


  /*
   * Disable submit button while API request
   * is in progress.
   */

  submitButton.disabled = true;


  submitButton.textContent =
    isEditing
      ? "Saving..."
      : "Registering...";


  try {

    const response =
      await fetch(
        isEditing
          ? `${API_URL}/${encodeURIComponent(editingId)}`
          : API_URL,
        {
          method: isEditing
            ? "PUT"
            : "POST",

          headers: {
            "Content-Type":
              "application/json"
          },

          body:
            JSON.stringify(animalData)
        }
      );


    if (!response.ok) {

      throw new Error(
        `${
          isEditing
            ? "Update"
            : "Registration"
        } failed (${response.status}).`
      );
    }


    const savedAnimal =
      await response.json();


    /* -------------------------------------------------------
       UPDATE LOCAL ARRAY
       ------------------------------------------------------- */

    if (isEditing) {

      animals =
        animals.map((animal) =>
          String(animal.id) ===
          String(savedAnimal.id)
            ? savedAnimal
            : animal
        );


      showApiMessage(
        "success",
        `${savedAnimal.name} was updated successfully.`
      );

    } else {

      animals =
        [...animals, savedAnimal];


      showApiMessage(
        "success",
        `${savedAnimal.name} was registered successfully.`
      );
    }


    /*
     * Reset form and render updated list
     * without reloading the page.
     */

    resetForm();

    renderAnimals();


  } catch (error) {

    showApiMessage(
      "danger",
      `The record could not be saved. ${error.message}`
    );


  } finally {

    /*
     * Always re-enable the button after
     * the request finishes.
     */

    submitButton.disabled =
      false;


    submitButton.textContent =
      animalIdInput.value
        ? "Save Changes"
        : "Register Animal";
  }
}


/* =========================================================
   FORM VALIDATION
   ========================================================= */

function validateForm() {

  const errors = {};


  const name =
    formFields.name.value.trim();

  const species =
    formFields.species.value;

  const breed =
    formFields.breed.value.trim();

  const ageText =
    formFields.age.value.trim();

  const age =
    Number(ageText);

  const gender =
    formFields.gender.value;

  const arrivalDate =
    formFields.arrivalDate.value;

  const status =
    formFields.status.value;

  const photoUrl =
    formFields.photoUrl.value.trim();


  /* NAME */

  if (!name) {

    errors.name =
      "Name is required.";

  } else if (name.length < 2) {

    errors.name =
      "Name must be at least 2 characters.";
  }


  /* SPECIES */

  if (
    !allowedSpecies.includes(species)
  ) {

    errors.species =
      "Please select a valid species.";
  }


  /* BREED */

  if (!breed) {

    errors.breed =
      "Breed is required.";
  }


  /* AGE */

  if (
    !ageText ||
    !Number.isFinite(age) ||
    age < 0
  ) {

    errors.age =
      "Age must be a non-negative number.";
  }


  /* GENDER */

  if (
    !allowedGenders.includes(gender)
  ) {

    errors.gender =
      "Please select a valid gender.";
  }


  /* ARRIVAL DATE */

  if (!arrivalDate) {

    errors.arrivalDate =
      "Arrival date is required.";
  }


  /* STATUS */

  if (
    !allowedStatuses.includes(status)
  ) {

    errors.status =
      "Please select a valid status.";
  }


  /* PHOTO URL */

  if (!photoUrl) {

    errors.photoUrl =
      "Photo URL is required.";

  } else {

    try {

      const parsedUrl =
        new URL(photoUrl);


      if (
        !["http:", "https:"].includes(
          parsedUrl.protocol
        )
      ) {

        errors.photoUrl =
          "Photo URL must use HTTP or HTTPS.";
      }


    } catch {

      errors.photoUrl =
        "Please enter a valid photo URL.";
    }
  }


  return errors;
}


/* =========================================================
   SHOW VALIDATION ERRORS
   ========================================================= */

function showValidationErrors(errors) {

  Object.entries(errors).forEach(
    ([fieldName, message]) => {

      formFields[fieldName]
        .classList.add("is-invalid");


      errorElements[fieldName]
        .textContent = message;
    }
  );
}


/* =========================================================
   CLEAR VALIDATION
   ========================================================= */

function clearValidation() {

  Object.keys(formFields).forEach(
    (fieldName) => {

      if (
        fieldName in errorElements
      ) {

        formFields[fieldName]
          .classList.remove(
            "is-invalid"
          );


        errorElements[fieldName]
          .textContent = "";
      }
    }
  );
}


/* =========================================================
   GET DATA FROM FORM
   ========================================================= */

function getFormData() {

  return {

    name:
      formFields.name.value.trim(),

    species:
      formFields.species.value,

    breed:
      formFields.breed.value.trim(),

    age:
      Number(formFields.age.value),

    gender:
      formFields.gender.value,

    vaccinated:
      formFields.vaccinated.checked,

    arrivalDate:
      formFields.arrivalDate.value,

    status:
      formFields.status.value,

    notes:
      formFields.notes.value.trim(),

    photoUrl:
      formFields.photoUrl.value.trim()
  };
}


/* =========================================================
   MARK AS ADOPTED
   PATCH /animals/:id
   ========================================================= */

async function markAsAdopted(id) {

  const animal =
    animals.find(
      (item) =>
        String(item.id) === String(id)
    );


  /*
   * Do nothing if animal doesn't exist
   * or is already adopted.
   */

  if (
    !animal ||
    animal.status === "Adopted"
  ) {

    return;
  }


  hideApiMessage();


  try {

    const response =
      await fetch(
        `${API_URL}/${encodeURIComponent(id)}`,
        {
          method: "PATCH",

          headers: {
            "Content-Type":
              "application/json"
          },

          body: JSON.stringify({
            status: "Adopted"
          })
        }
      );


    if (!response.ok) {

      throw new Error(
        `Adoption update failed (${response.status}).`
      );
    }


    const updatedAnimal =
      await response.json();


    /*
     * Update local array.
     */

    animals =
      animals.map((item) =>
        String(item.id) ===
        String(updatedAnimal.id)
          ? updatedAnimal
          : item
      );


    /*
     * Re-render immediately.
     */

    renderAnimals();


    showApiMessage(
      "success",
      `${updatedAnimal.name} has been marked as adopted.`
    );


  } catch (error) {

    showApiMessage(
      "danger",
      `The animal could not be marked as adopted. ${error.message}`
    );
  }
}


/* =========================================================
   DELETE /animals/:id
   ========================================================= */

async function deleteAnimal(id) {

  const animal =
    animals.find(
      (item) =>
        String(item.id) === String(id)
    );


  if (!animal) {
    return;
  }


  /*
   * Confirmation prevents accidental deletion.
   *
   * This is NOT used for validation messages.
   */

  if (
    !window.confirm(
      `Delete the record for ${animal.name}?`
    )
  ) {

    return;
  }


  hideApiMessage();


  try {

    const response =
      await fetch(
        `${API_URL}/${encodeURIComponent(id)}`,
        {
          method: "DELETE"
        }
      );


    if (!response.ok) {

      throw new Error(
        `Delete failed (${response.status}).`
      );
    }


    /*
     * Remove deleted animal from local array.
     */

    animals =
      animals.filter(
        (item) =>
          String(item.id) !== String(id)
      );


    /*
     * If the deleted animal was being edited,
     * reset the form.
     */

    if (
      String(animalIdInput.value) ===
      String(id)
    ) {

      resetForm();
    }


    /*
     * Update UI without page reload.
     */

    renderAnimals();


    showApiMessage(
      "success",
      `${animal.name} was removed from the records.`
    );


  } catch (error) {

    showApiMessage(
      "danger",
      `The animal could not be deleted. ${error.message}`
    );
  }
}


/* =========================================================
   RESET FORM
   ========================================================= */

function resetForm() {

  animalForm.reset();

  animalIdInput.value = "";

  formFields.status.value =
    "Available";

  clearValidation();

  setEditMode(false);
}


/* =========================================================
   SET FORM EDIT MODE
   ========================================================= */

function setEditMode(isEditing) {

  if (isEditing) {

    formHeading.textContent =
      "Edit Animal";


    formModeBadge.textContent =
      "Editing";


    formModeBadge.className =
      "badge text-bg-warning";


    submitButton.textContent =
      "Save Changes";


    cancelEditButton.classList.remove(
      "d-none"
    );


  } else {

    formHeading.textContent =
      "Register an Animal";


    formModeBadge.textContent =
      "New Record";


    formModeBadge.className =
      "badge text-bg-primary";


    submitButton.textContent =
      "Register Animal";


    cancelEditButton.classList.add(
      "d-none"
    );
  }
}


/* =========================================================
   API MESSAGE
   ========================================================= */

function showApiMessage(
  type,
  message
) {

  apiMessage.className =
    `alert alert-${type}`;


  apiMessage.textContent =
    message;


  apiMessage.classList.remove(
    "d-none"
  );
}


/* =========================================================
   HIDE API MESSAGE
   ========================================================= */

function hideApiMessage() {

  apiMessage.classList.add(
    "d-none"
  );

  apiMessage.textContent = "";
}

